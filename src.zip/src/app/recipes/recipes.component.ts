import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Recipe } from './recipe.model'

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {
  //@Output() selectedRecipeDetails = new EventEmitter<Recipe>();
   selectedRecipeDetails:Recipe;

  constructor() { }

  ngOnInit() {
  }

  SelectedRecipe(recipe: Recipe) {
    this.selectedRecipeDetails=recipe;
    console.log(recipe.name);
  }

}
