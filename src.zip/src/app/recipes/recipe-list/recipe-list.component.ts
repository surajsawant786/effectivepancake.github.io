import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Recipe } from '../recipe.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  @Output() recipeWasSelected = new EventEmitter<Recipe>();
  recipes: Recipe[] = [
    new Recipe('Italian Chicken', 'Italian Chicken Sheet Pan Supper', 'https://i.pinimg.com/originals/59/6a/46/596a46f5278f25a397803823b47f83eb.png'),
    new Recipe('Tacos', 'Aussie-style beef and salad tacos', 'https://img.taste.com.au/JUP14u0b/w1200-h630-cfill/taste/2016/11/aussie-style-beef-and-salad-tacos-86525-1.jpeg')
  ];
  constructor() { }

  ngOnInit() {
  }

  onRecipeSelected(recipe: Recipe) {
    this.recipeWasSelected.emit(recipe);
  }

}
