import { Component, OnInit } from '@angular/core';
import { Ingredient } from '../shared/ingredient.model'

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {

  ingredients: Ingredient[] = [
    new Ingredient('Apples', 5),
    new Ingredient('Tomatoes', 10),
    new Ingredient('Oranges', 16),
    new Ingredient('Strawberries', 20),
    new Ingredient('Eggs', 30),
    new Ingredient('Cheese', 10)
  ];

  constructor() { }

  ngOnInit() { }

  addIngd(ingdData: Ingredient) {
    this.ingredients.push(ingdData);
  }

}
