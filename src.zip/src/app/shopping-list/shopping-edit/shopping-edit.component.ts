import { Component, OnInit, EventEmitter, ElementRef, ViewChild, Output } from '@angular/core';
import { Ingredient } from '../../shared/ingredient.model'

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit {
  @Output('ingdAdded') ingdAdded = new EventEmitter<{ name: string, amt: number }>();
  constructor() { }

  ngOnInit() { }

  @ViewChild('amountInput') amountInput: ElementRef;

  onAddIngd(nameInput: HTMLInputElement) {
    this.ingdAdded.emit({
      name: nameInput.value,
      amt: this.amountInput.nativeElement.value
    })
  }

}
